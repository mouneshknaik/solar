const nodeExternals = require('webpack-node-externals');
const WebpackShellPlugin = require('webpack-shell-plugin');
const path = require('path');
const moment = require('moment')
const fs = require('fs');
const webpack = require("webpack");
const TerserPlugin = require('terser-webpack-plugin');

const {
    NODE_ENV = 'production',
} = process.env;

var pkg = require('./package.json');
var datetime = moment().format('YYYYMMDDhhmm');
// var time = new Date().toLocaleTimeString().split(':').splice(0, 2).join('');

let prodBundleName = `prod-server-dist-${pkg.version}-${datetime}.js`;
let devBundleName = `dev-server-dist-${pkg.version}-${datetime}.js`;

// console.log('PROD BUILD NAME : ' + prodBundleName);
// 

class DevBuildEndPlugin {
    apply(compiler) {
        compiler.hooks.done.tapAsync('DevBuildPlugin', (compilation, cb) => {
            fs.writeFile('./build/dev', `${devBundleName}`, (err, data) => {
                if (err) {
                    return cb(err);
                }
                console.log('DEV BUILD NAME : ' + devBundleName);
                cb();
            });

        });
    }
}

class ProdBuildEndPlugin {
    apply(compiler) {
        compiler.hooks.done.tapAsync('DevBuildPlugin', (compilation, cb) => {
            fs.writeFile('./build/prod', `${prodBundleName}`, (err, data) => {
                if (err) {
                    return cb(err);
                }
                console.log('PROD BUILD NAME : ' + prodBundleName);
                cb();
            });

        });
    }
}

module.exports = [{
    name: 'prod',
    entry: './src/server.ts',
    mode: 'production',
    target: 'node',
    output: {
        path: path.resolve(__dirname, 'build'),
        filename: prodBundleName
    },
    resolve: {
        extensions: ['.ts', '.js'],
    },
    module: {
        rules: [{
            test: /\.ts$/,
            use: [
                'ts-loader',
            ]
        }]
    },
    watch: NODE_ENV === 'development',
    externals: [nodeExternals()],
    plugins: [
        new ProdBuildEndPlugin(),
        //     new WebpackShellPlugin({
        //         onBuildEnd: ['yarn run:dev']
        //     })
    ],
}, {
    name: 'dev',
    entry: './src/server.ts',
    mode: 'development',
    target: 'node',
    output: {
        path: path.resolve(__dirname, 'build'),
        filename: devBundleName
    },
    resolve: {
        extensions: ['.ts', '.js'],
    },
    module: {
        rules: [{
            test: /\.ts$/,
            use: [
                'ts-loader',
            ]
        }]
    },
    watch: NODE_ENV === 'development',
    optimization: {
        minimize: true,
        minimizer: [
            new TerserPlugin()
        ],
    },
    externals: [nodeExternals()],
    plugins: [
        new DevBuildEndPlugin(),
        //     new WebpackShellPlugin({
        //         onBuildEnd: ['yarn run:dev']
        //     })
    ],

}]