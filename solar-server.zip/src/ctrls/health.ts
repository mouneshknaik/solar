import * as express from "express";


export const getHealth = (req: any, res: any) => { res.send('Healthy') };
