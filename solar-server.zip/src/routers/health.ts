import * as express from "express";

export const router = express.Router();

import * as helthCtrl from '../ctrls/health';

router.get("/", helthCtrl.getHealth);

