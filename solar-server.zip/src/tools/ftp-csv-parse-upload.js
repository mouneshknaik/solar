
const path = require('path');
const gunzip = require('gunzip-file');
const fs = require('fs');
const moment = require('moment');
const axios = require('axios');
const base64 = require('base-64');
var qs = require('qs');

var config = {
    tempDir: '.',
    srcHome: "/workplace/solar/shared_drive_FTP",
    srcFile: "WD00CA43_MODBUS_200612_053100.csv.gz",
    time: Date.now(),
    auth: {},
    zonosAuthUrl: "https://demo.zonos.de/southbound-api/oauth/token",
    zonosUrl: "https://demo.zonos.de/southbound-api",
    apiKey: "p4",
    apiSecret: "cX6H9eqe",
    deviceId: "Test_Device",
    profile: "1-0:96.80.32*255",
};

let srcFilePath = path.resolve(`${config.srcHome}/DATA/MODBUS/${config.srcFile}`);
let destFilePath = path.resolve(`${config.tempDir}/${config.srcFile}.csv`);

const FUNCTIONS = {
    EQUAL: (val1) => val1,
    UINT32: (val1, val2) => (val1 * 65536 + val2) * 0.1,
    UINT16: (val1) => val1 * 0.1,
    INFINITY: () => -Infinity,
};

let transformers205080 = [{ "reqReadFctCode": 3, "varPosition": 00, "varIndex": 1, "varName": "OnOff", "varDesc": "Remote On/Off", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 06, "varIndex": 2, "varName": "Pmax H", "varDesc": "Normal power", "varUnit": "VA", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 07, "varIndex": 3, "varName": "Pmax L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 08, "varIndex": 4, "varName": "Vnormal", "varDesc": "Normal work PV voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": "1 - 0: 12.7.0 * 255" },
{ "reqReadFctCode": 3, "varPosition": 09, "varIndex": 5, "varName": "Fw version H", "varDesc": "Firmware version (high)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 10, "varIndex": 6, "varName": "Fw version M", "varDesc": "Firmware version (middle)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 11, "varIndex": 7, "varName": "Fw version L", "varDesc": "Firmware version (low)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 12, "varIndex": 8, "varName": "Fw version 2H", "varDesc": "Control Firmware version (high)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 13, "varIndex": 9, "varName": "Fw version 2M", "varDesc": "Control Firmware version (middle)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 14, "varIndex": 10, "varName": "Fw version 2L", "varDesc": "Control Firmware version (low)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 18, "varIndex": 11, "varName": "Time start", "varDesc": "Start time", "varUnit": "s", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 30, "varIndex": 12, "varName": "Com", "varDesc": "Modbus Device ID", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 45, "varIndex": 13, "varName": "Sys Year", "varDesc": "System time- Year", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 46, "varIndex": 14, "varName": "Sys Month", "varDesc": "System time- Month", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 47, "varIndex": 15, "varName": "Sys Day", "varDesc": "System time- Day", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 48, "varIndex": 16, "varName": "Sys Hour", "varDesc": "System time- Hour", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 49, "varIndex": 17, "varName": "Sys Min", "varDesc": "System time- Min", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 50, "varIndex": 18, "varName": "Sys Sec", "varDesc": "System time- Second", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 88, "varIndex": 19, "varName": "Modbus Version", "varDesc": "Modbus Version", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 0, "varIndex": 101, "varName": "Inverter Status", "varDesc": "Inverter Running Status", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 1, "varIndex": 102, "varName": "Ppv H", "varDesc": "Input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 2, "varIndex": 103, "varName": "Ppv L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 3, "varIndex": 104, "varName": "Vpv1", "varDesc": "PV1 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 4, "varIndex": 105, "varName": "PV1Curr", "varDesc": "PV1 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 5, "varIndex": 106, "varName": "Ppv1 H", "varDesc": "PV1 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 6, "varIndex": 107, "varName": "Ppv1 L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 7, "varIndex": 108, "varName": "Vpv2", "varDesc": "PV2 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 8, "varIndex": 109, "varName": "PV2Curr", "varDesc": "PV2 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 9, "varIndex": 110, "varName": "Ppv2 H", "varDesc": "PV2 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 10, "varIndex": 111, "varName": "Ppv2 L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 11, "varIndex": 112, "varName": "Vpv3", "varDesc": "PV3 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 12, "varIndex": 113, "varName": "PV3Curr", "varDesc": "PV3 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 13, "varIndex": 114, "varName": "Ppv3 H", "varDesc": "PV3 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 14, "varIndex": 115, "varName": "Ppv3 L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 35, "varIndex": 116, "varName": "Pac H", "varDesc": "Output Power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 36, "varIndex": 117, "varName": "Pac L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 53, "varIndex": 118, "varName": "Eactoday H", "varDesc": "Energy Generated -Today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": "1 - 0: 2.8.0 * 255" },
{ "reqReadFctCode": 4, "varPosition": 54, "varIndex": 119, "varName": "Eac today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 55, "varIndex": 120, "varName": "Eac total H", "varDesc": "Energy Generated -Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": "1 - 0: 1.8.0 * 255" },
{ "reqReadFctCode": 4, "varPosition": 56, "varIndex": 121, "varName": "Eac total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 57, "varIndex": 122, "varName": "Time total H", "varDesc": "Total Work Time", "varUnit": "hh:mm", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 58, "varIndex": 123, "varName": "Time total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 59, "varIndex": 124, "varName": "Epv1_today H", "varDesc": "PV1 Energy Generated -Today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 60, "varIndex": 125, "varName": "Epv1_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 61, "varIndex": 126, "varName": "Epv1_total H", "varDesc": "PV1 Energy Generated -Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 62, "varIndex": 127, "varName": "Epv1_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 63, "varIndex": 128, "varName": "Epv2_today H", "varDesc": "PV2 Energy Generated -Today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 64, "varIndex": 129, "varName": "Epv2_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 65, "varIndex": 130, "varName": "Epv2_total H", "varDesc": "PV2 Energy Generated -Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 66, "varIndex": 131, "varName": "Epv2_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 67, "varIndex": 132, "varName": "Epv3_today H", "varDesc": "PV3 Energy Generated -Today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 68, "varIndex": 133, "varName": "Epv3_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 69, "varIndex": 134, "varName": "Epv3_total H", "varDesc": "PV3 Energy Generated -Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 70, "varIndex": 135, "varName": "Epv3_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 91, "varIndex": 136, "varName": "Epv_total H", "varDesc": "PV Energy Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 92, "varIndex": 137, "varName": "Epv_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 93, "varIndex": 138, "varName": "Temp1", "varDesc": "Inverter temperature", "varUnit": "Deg.C.", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 94, "varIndex": 139, "varName": "Temp2", "varDesc": "IGBT Temperature", "varUnit": "Deg.C.", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 98, "varIndex": 140, "varName": "P Bus Voltage", "varDesc": "P Bus inside Voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 99, "varIndex": 141, "varName": "N Bus Voltage", "varDesc": "N Bus inside Voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 105, "varIndex": 142, "varName": "Fault code", "varDesc": "Inverter fault code", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 106, "varIndex": 143, "varName": "Fault Bitcode H", "varDesc": "Inverter fault code", "varUnit": "", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 107, "varIndex": 144, "varName": "Fault Bitcode L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 142, "varIndex": 145, "varName": "V _String1", "varDesc": "PV String1 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 143, "varIndex": 146, "varName": "Curr _String1", "varDesc": "PV String1 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": "1 - 0: 11.7.0 * 255" },
{ "reqReadFctCode": 4, "varPosition": 144, "varIndex": 147, "varName": "V _String2", "varDesc": "PV String2 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 145, "varIndex": 148, "varName": "Curr _String2", "varDesc": "PV String2 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 146, "varIndex": 149, "varName": "V _String3", "varDesc": "PV String3 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 147, "varIndex": 150, "varName": "Curr _String3", "varDesc": "PV String3 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 148, "varIndex": 151, "varName": "V _String4", "varDesc": "PV String4 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 149, "varIndex": 152, "varName": "Curr _String4", "varDesc": "PV String4 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 150, "varIndex": 153, "varName": "V _String5", "varDesc": "PV String5 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 151, "varIndex": 154, "varName": "Curr _String5", "varDesc": "PV String5 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 152, "varIndex": 155, "varName": "V _String6", "varDesc": "PV String6 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 153, "varIndex": 156, "varName": "Curr _String6", "varDesc": "PV String6 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 154, "varIndex": 157, "varName": "V _String7", "varDesc": "PV String7 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 155, "varIndex": 158, "varName": "Curr _String7", "varDesc": "PV String7 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 156, "varIndex": 159, "varName": "V _String8", "varDesc": "PV String8 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 157, "varIndex": 160, "varName": "Curr _String8", "varDesc": "PV String8 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 158, "varIndex": 161, "varName": "V _String9", "varDesc": "PV String9 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 159, "varIndex": 162, "varName": "Curr _String9", "varDesc": "PV String9 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 160, "varIndex": 163, "varName": "V _String10", "varDesc": "PV String10 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 161, "varIndex": 164, "varName": "Curr _String10", "varDesc": "PV String10 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 230, "varIndex": 165, "varName": "Sac H", "varDesc": "Output apparent power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 231, "varIndex": 166, "varName": "Sac L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 232, "varIndex": 167, "varName": "ReActPowerH", "varDesc": "Real Output Reactive Power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 233, "varIndex": 168, "varName": "ReActPowerL", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 234, "varIndex": 169, "varName": "ReAgtPowerMa×H", "varDesc": "Nominal Output Reactive Power", "varUnit": "VAR", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 235, "varIndex": 170, "varName": "ReAgtPowerMa×L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 236, "varIndex": 171, "varName": "ReActPower_Total H", "varDesc": "Reactive power generation", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 237, "varIndex": 172, "varName": "ReActPower_Total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null }];

const transformers530 = [{ "reqReadFctCode": 3, "varPosition": 00, "varIndex": 1, "varName": "OnOff", "varDesc": "The Inverter On/Off state and the auto start state", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 06, "varIndex": 2, "varName": "Pmax H", "varDesc": "Normal power", "varUnit": "VA", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 07, "varIndex": 3, "varName": "Pmax L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 08, "varIndex": 4, "varName": "Vnormal", "varDesc": "Normal work PV voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 09, "varIndex": 5, "varName": "Fw version H", "varDesc": "Firmware version (high)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 10, "varIndex": 6, "varName": "Fw version M", "varDesc": "Firmware version (middle)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 11, "varIndex": 7, "varName": "Fw version L", "varDesc": "Firmware version (low)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 12, "varIndex": 8, "varName": "Fw version 2H", "varDesc": "Control Firmware version (high)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 13, "varIndex": 9, "varName": "Fw version 2M", "varDesc": "Control Firmware version (middle)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 14, "varIndex": 10, "varName": "Fw version 2L", "varDesc": "Control Firmware version (low)", "varUnit": "", "varUnitType": "ASCII", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 18, "varIndex": 11, "varName": "Time start", "varDesc": "Start time", "varUnit": "s", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 30, "varIndex": 12, "varName": "Com", "varDesc": "Modbus Device ID", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 45, "varIndex": 13, "varName": "Sys Year", "varDesc": "System time- Year", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 46, "varIndex": 14, "varName": "Sys Month", "varDesc": "System time- Month", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 47, "varIndex": 15, "varName": "Sys Day", "varDesc": "System time- Day", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 48, "varIndex": 16, "varName": "Sys Hour", "varDesc": "System time- Hour", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 49, "varIndex": 17, "varName": "Sys Min", "varDesc": "System time- Min", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 50, "varIndex": 18, "varName": "Sys Sec", "varDesc": "System time- Second", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 3, "varPosition": 73, "varIndex": 19, "varName": "Modbus Version", "varDesc": "Modbus Version", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 0, "varIndex": 101, "varName": "Inverter Status", "varDesc": "Inverter Running Status", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 1, "varIndex": 102, "varName": "Ppv H", "varDesc": "Input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 2, "varIndex": 103, "varName": "Ppv L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 3, "varIndex": 104, "varName": "Vpv1", "varDesc": "PV1 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 4, "varIndex": 105, "varName": "PV1Curr", "varDesc": "PV1 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 5, "varIndex": 106, "varName": "PV1Watt H", "varDesc": "PV1 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 6, "varIndex": 107, "varName": "PV1Watt L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 7, "varIndex": 108, "varName": "Vpv2", "varDesc": "PV2 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 8, "varIndex": 109, "varName": "PV2Curr", "varDesc": "PV2 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 9, "varIndex": 110, "varName": "PV2Watt H", "varDesc": "PV2 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 10, "varIndex": 111, "varName": "PV2Watt L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 11, "varIndex": 112, "varName": "Pac H", "varDesc": "Output Power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 12, "varIndex": 113, "varName": "Pac L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 26, "varIndex": 114, "varName": "Energy today H", "varDesc": "Energy Generated -Today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 27, "varIndex": 115, "varName": "Energy today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 28, "varIndex": 116, "varName": "Energy total H", "varDesc": "Energy Generated -Total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 29, "varIndex": 117, "varName": "Energy total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 30, "varIndex": 118, "varName": "Time total H", "varDesc": "Total Work Time", "varUnit": "hh:mm", "varUnitType": "UINT32", "varFormula": "(Hx65536+L)x 0.5", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 31, "varIndex": 119, "varName": "Time total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 32, "varIndex": 120, "varName": "Temperature", "varDesc": "Inverter temperature", "varUnit": "Deg.C.", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 40, "varIndex": 121, "varName": "Fault code", "varDesc": "Inverter fault code", "varUnit": "", "varUnitType": "UINT16", "varFormula": "", "varValue": "", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 41, "varIndex": 122, "varName": "IPM Temperature", "varDesc": "IGBT Temperature", "varUnit": "Deg.C.", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 42, "varIndex": 123, "varName": "P Bus Voltage", "varDesc": "P Bus inside Voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 43, "varIndex": 124, "varName": "N Bus Voltage", "varDesc": "N Bus inside Voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 48, "varIndex": 125, "varName": "Epv1_today H", "varDesc": "PV1 Energy today", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 49, "varIndex": 126, "varName": "Epv1_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 50, "varIndex": 127, "varName": "Epv1_total H", "varDesc": "PV1 Energy total", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 51, "varIndex": 128, "varName": "Epv1_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 52, "varIndex": 129, "varName": "Epv2_today H", "varDesc": "PV2 Energy today", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 53, "varIndex": 130, "varName": "Epv2_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 54, "varIndex": 131, "varName": "Epv2_total H", "varDesc": "PV2 Energy total", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 55, "varIndex": 132, "varName": "Epv2_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 56, "varIndex": 133, "varName": "Epv_total H", "varDesc": "PV Energy total", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 57, "varIndex": 134, "varName": "Epv_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 58, "varIndex": 135, "varName": "Rac H", "varDesc": "AC Reactive power", "varUnit": "Var", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 59, "varIndex": 136, "varName": "Rac L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 60, "varIndex": 137, "varName": "E_rac_today H", "varDesc": "AC Reactive energy Today", "varUnit": "Varh", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 61, "varIndex": 138, "varName": "E_rac_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 62, "varIndex": 139, "varName": "E_rac_total H", "varDesc": "AC Reactive energy Total", "varUnit": "kVarh", "varUnitType": "UINT32", "varFormula": "Hx65536+Lx0.1", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 63, "varIndex": 140, "varName": "E_rac_ total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 70, "varIndex": 141, "varName": "V _String1", "varDesc": "PV String1 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 71, "varIndex": 142, "varName": "Curr _String1", "varDesc": "PV String1 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 72, "varIndex": 143, "varName": "V _String2", "varDesc": "PV String2 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 73, "varIndex": 144, "varName": "Curr _String2", "varDesc": "PV String2 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 74, "varIndex": 145, "varName": "V _String3", "varDesc": "PV String3 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 75, "varIndex": 146, "varName": "Curr _String3", "varDesc": "PV String3 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 76, "varIndex": 147, "varName": "V _String4", "varDesc": "PV String4 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 77, "varIndex": 148, "varName": "Curr _String4", "varDesc": "PV String4 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 78, "varIndex": 149, "varName": "V _String5", "varDesc": "PV String5 voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 79, "varIndex": 150, "varName": "Curr _String5", "varDesc": "PV String5 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 80, "varIndex": 151, "varName": "V _String6", "varDesc": "PV String6voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 81, "varIndex": 152, "varName": "Curr _String6", "varDesc": "PV String6 current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 120, "varIndex": 153, "varName": "PV3 Voltage", "varDesc": "PV3 input voltage", "varUnit": "V", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 121, "varIndex": 154, "varName": "PV3 Current", "varDesc": "PV3 input current", "varUnit": "A", "varUnitType": "UINT16", "varFormula": "x 0.1", "varValue": "UINT16", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 122, "varIndex": 155, "varName": "PV3Watt H", "varDesc": "PV3 input power", "varUnit": "W", "varUnitType": "UINT32", "varFormula": "Hx65536+L", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 123, "varIndex": 156, "varName": "PV3Watt L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 124, "varIndex": 157, "varName": "Epv3_today H", "varDesc": "PV3 Energy today", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "Hx65536+L", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 125, "varIndex": 158, "varName": "Epv3_today L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 126, "varIndex": 159, "varName": "Epv3_total H", "varDesc": "PV3 Energy total", "varUnit": "kWH", "varUnitType": "UINT32", "varFormula": "Hx65536+L", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 127, "varIndex": 160, "varName": "Epv3_total L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 128, "varIndex": 161, "varName": "Faultcode H", "varDesc": "Inverter fault code", "varUnit": "", "varUnitType": "UINT32", "varFormula": "", "varValue": "UINT32", "varObis": null },
{ "reqReadFctCode": 4, "varPosition": 129, "varIndex": 162, "varName": "Faultcode L", "varDesc": "", "varUnit": "", "varUnitType": "", "varFormula": "", "varValue": "INFINITY", "varObis": null }];

// Select transformers for as per drive
const transformers = transformers205080;



const zonosAuthenticate = () => {
    config.time = Date.now();
    const credBase64 = base64.encode(config.apiKey + ':' + config.apiSecret);
    return axios.post(config.zonosAuthUrl, qs.stringify({
        'grant_type': 'client_credentials',
        'scope': 'connector'
    }), {
            headers: {
                'Authorization': `Basic ${credBase64}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(function (response) {
            // handle success
            config.auth = response.data;
            console.log(config.auth);
            return response;
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        })
}

const uploadData = async (opt) => {
    console.log(opt);

    axios.post(config.zonosUrl + `/api/1/bulk/profile-reads`,
        [{
            "deviceId": opt.deviceId,
            "measuredAt": opt.measuredAt,
            "profile": opt.profile,
            "readingReason": 1,
            "statusWord": 0,
            "values": opt.values
        }]
        , {
            headers: {
                "authorization": `Bearer ${config.auth.access_token}`,
            }
        }).then(async (response) => {
            console.log("Upload success: " + opt.inveterName)
        })
        .catch((error) => {
            // console.log(error);
        })
}

const readRequestTable = (defFileName) => {
    let result = [];
    const defFilePath = path.resolve(`${config.srcHome}/DEF/MODBUS/${defFileName}`);
    const defData = fs.readFileSync(defFilePath, 'utf8');

    let lines = defData.split('\n').filter(o => o.trim());


    let startIndex = 0;
    let endIndex = 0;

    (lines || []).forEach((line, i) => {
        if (!startIndex && line == "Modbus_RequestsTables={\r") {
            startIndex = i + 2;
        }
        if (!endIndex && startIndex && line == "}\r") {
            endIndex = i;
        }
    });

    // console.log(startIndex + ' , ' + endIndex);
    // console.log(lines);

    let modbusRequestArray = lines.slice(startIndex, endIndex);

    // console.log(modbusRequestArray);

    if (modbusRequestArray) {
        let headers = modbusRequestArray[0].split(';');
        headers[0] = headers[0].replace('#', '').trim();
        headers = headers.map((header) => header.trim()).filter((o) => o);

        // console.log(headers);

        modbusRequestArray.forEach((line, i) => {
            if (i > 0) {
                line = line.trim();
                let value = {};
                let items = line.split(';');
                if (items.length > 0) {
                    headers.forEach((header, j) => {
                        let v = items[j];
                        if (v && !isNaN(v)) {
                            v = parseFloat(v);
                        }
                        value[header] = v;
                    });
                    result.push(value);
                }
            }
        });
    }


    return result;
}


const readVariableTable = (defFileName) => {
    let result = [];
    const defFilePath = path.resolve(`${config.srcHome}/DEF/MODBUS/${defFileName}`);
    const defData = fs.readFileSync(defFilePath, 'utf8');

    let lines = defData.split('\n').filter(o => o.trim());

    let startIndex = 0;
    let endIndex = 0;

    (lines || []).forEach((line, i) => {
        if (!startIndex && line == "Modbus_VariablesTables={\r") {
            startIndex = i + 2;
        }
        if (!endIndex && startIndex && line == "}\r") {
            endIndex = i;
        }
    });

    // console.log(startIndex + ' , ' + endIndex);
    // console.log(lines);

    let modbusVariableArray = lines.slice(startIndex, endIndex);

    // console.log(modbusVariableArray);

    if (modbusVariableArray) {
        let headers = modbusVariableArray[0].split(';');
        headers[0] = headers[0].replace('#', '').trim();
        headers = headers.map((header) => header.trim()).filter((o) => o);

        // console.log(headers);

        modbusVariableArray.forEach((line, i) => {
            if (i > 0) {
                line = line.trim();
                let value = {};
                let items = line.split(';');
                if (items.length > 0) {
                    headers.forEach((header, j) => {
                        let v = items[j];
                        if (v && !isNaN(v)) {
                            v = parseFloat(v);
                        }
                        value[header] = v;
                    });
                    result.push(value);
                }
            }
        });
    }

    return result;
}

const readCsvInvetersData = () => {
    const csvData = fs.readFileSync(destFilePath, 'utf8');

    let lines = csvData.split('\n');
    // console.log(lines);

    let inveters = [];
    let currentLineNo = 0;
    while (currentLineNo < lines.length - 4) {
        let inveter = {};
        let _names = lines[currentLineNo + 0];
        let _defs = lines[currentLineNo + 1];
        let _indexes = lines[currentLineNo + 2].split(';');
        let _values = lines[currentLineNo + 3].split(';');

        let date = moment(_values[0], 'DD/MM/YY-hh:mm:ss').toDate();

        inveter.name = _names;
        inveter.index = _names.split(';')[1];
        inveter.def = _defs.split(';')[1];
        inveter.count = _indexes[0];
        inveter.date = date;

        let inverterRequests = readRequestTable(inveter.def);
       

        let inverterVariables = readVariableTable(inveter.def);

        // Assign reqReadFctCode in all the veriable
        // console.log(inverterVariables)
        inverterRequests.forEach((request, ) => {
            inverterVariables.forEach(o => {
                if (o.varReqIndex == request.reqIndex) {
                    o.reqReadFctCode = request.reqReadFctCode;
                    // console.log(o.varReqIndex + ' , ' + request.reqIndex);
                }
            });
        });

        // console.log(inverterVariables);

        let readings = [];
        _indexes.forEach((index, i) => {
            if (i > 0) {
                let variable = inverterVariables.find(o => o.varIndex == index);
                if (variable) {
                    let transformer = transformers.find(o => o.reqReadFctCode == variable.reqReadFctCode && o.varPosition == variable.varPosition - 1);
                    if (transformer) {
                        transformer.varValue = transformer.varValue || 'EQUAL';
                        let val1 = (_values[i] || '').trim();
                        let val2 = (_values[i - 1] || '').trim();

                        if (!isNaN(val1)) val1 = parseFloat(val1);
                        if (!isNaN(val2)) val2 = parseFloat(val2);

                        let element = {
                            date: date,
                            variable: variable,
                            transformer: transformer,
                            rawValue: val1,
                            index: parseInt(index || 0),
                            value: FUNCTIONS[transformer.varValue](val1, val2),
                        };
                        // console.log(element);
                        readings.push(element);
                    }
                }
            }
        });

        currentLineNo += 4;

        // Remove all -Infinite values
        readings = readings.filter((o) => o.value != -Infinity);

        inveter.readings = readings;
        inveters.push(inveter)
    }

    return inveters;
};


const executor = () => {
    gunzip(srcFilePath, destFilePath, async () => {
        console.log('Extraction completed.');

        const inveters = readCsvInvetersData();
        // console.log(inveters);
       
        fs.unlinkSync(destFilePath);

        console.log('Data extraction done');

        await zonosAuthenticate();

        (inveters || []).forEach(inveter => {

            let values = inveter.readings.filter(reading => reading.transformer.varObis);

            if (values && values.length) {
                values = values.map(v => {
                    return {
                        measuredAt: v.date,
                        register: v.transformer.varObis,
                        unit: v.transformer.varUnit,
                        value: v.value,
                    }
                });

                uploadData({
                    inveterName: inveter.name,
                    measuredAt: inveter.date,
                    deviceId: config.deviceId + '_' + inveter.index,
                    profile: config.profile,
                    values
                });
            }
        });

    });
}


executor();