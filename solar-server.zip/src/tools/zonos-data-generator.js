const axios = require('axios');
const base64 = require('base-64');
var qs = require('qs');
const config = {
    time: Date.now(),
    auth: {},
    zonosAuthUrl: "https://demo.zonos.de/southbound-api/oauth/token",
    zonosUrl: "https://demo.zonos.de/southbound-api",
    apiKey: "p4",
    apiSecret: "cX6H9eqe",
    generators: [{
        deviceId: "Test_Device_1",
        profile: "1-0:96.80.32*255",
        values: [{
            obis: "1-0:96.80.32*255",
            unit: "kWh",
            minValue: 1000,
            MaxValue: 2000,
        }],
        delay: 0, // Minutes
        interval: .10, // Minutes
        limit: 0
    },]
};
const auth=new Promise((resolve,reject)=>{
    config.time = Date.now();
    const credBase64 = base64.encode(config.apiKey + ':' + config.apiSecret);
    return axios.post(config.zonosAuthUrl, qs.stringify({
        'grant_type': 'client_credentials',
        'scope': 'connector'
    }), {
            headers: {
                'Authorization': `Basic ${credBase64}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(function (response) {
            // handle success
            config.auth = response.data;
            // console.log(config.auth);
            // return response;
            resolve(response)
        })
        .catch(function (error) {
            // handle error
            reject(error);
            // console.log(error);
        })
});
const authenticate = () => {
    config.time = Date.now();
    const credBase64 = base64.encode(config.apiKey + ':' + config.apiSecret);
    return axios.post(config.zonosAuthUrl, qs.stringify({
        'grant_type': 'client_credentials',
        'scope': 'connector'
    }), {
            headers: {
                'Authorization': `Basic ${credBase64}`,
                'Content-Type': 'application/x-www-form-urlencoded',
            }
        })
        .then(function (response) {
            // handle success
            config.auth = response.data;
            console.log(config.auth);
            return response;
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        })
}

const random = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

const uploadData = async (generator) => {
    if ((Date.now() - config.time) > 2 * 60 * 60 * 1000) { // refresh auth every 2 hrs
        config.auth = await authenticate();
    }
    const date = new Date().toISOString();
    const values = [];
    (generator.values || []).forEach((v) => {
        let entry = {
            "measuredAt": date,
            "register": v.obis,
            "unit": v.unit,
            "value": random(v.minValue, v.MaxValue)
        };
        values.push(entry);
    })
    axios.post(config.zonosUrl + `/api/1/bulk/profile-reads`,
        [{
            "deviceId": generator.deviceId,
            "measuredAt": date,
            "profile": generator.obis,
            "readingReason": 0,
            "statusWord": 0,
            "values": values
        }], {
            headers: {
                "authorization": `Bearer ${config.auth.access_token}`,
            }
        }).then(async function (response) {
            // handle success
            generator.index++;
            console.log(`Meter data sent to [${generator.deviceId}] [${generator.interval}m] [${generator.index}]`);
            if (generator.limit && generator.limit < generator.index) {
                console.log(`Limit reached ${generator.limit}: STOPPED`);
                return response;
            }
            setTimeout(() => {
                uploadData(generator);
            }, generator.interval * 60 * 1000);
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        })
}

const executor = async () => {
    // await authenticate();
    await auth.then(data=>{
        console.log(data);
    }).catch(err=>{
        console.log(err);
    })
    // config.generators.forEach((generator) => {
    //     setTimeout(() => {
    //         generator.index = 0;
    //         uploadData(generator);
    //     }, generator.delay * 60 * 1000);
    // })
}

executor();