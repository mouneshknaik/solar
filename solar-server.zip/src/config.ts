
import * as os from 'os';
import * as fs from 'fs';
import * as path from 'path';
import * as _ from 'lodash';

export const config = {
    "port": 4000,
    "appName": "hesplus",
    "timezone": "Asia/Kolkata",
}

let configPath = path.resolve(os.homedir(), `.server-config/${config.appName}/config.json`);
console.log("Config path : " + configPath);
console.log("Config exist :" + fs.existsSync(configPath));
try {
    if (fs.existsSync(configPath)) {
        let rawdata = fs.readFileSync(configPath, 'utf8');
        if (rawdata) {
            let conf = JSON.parse(rawdata);
            if (conf) {
                _.merge(config, conf);
                console.log("Config loaded from server");
                console.dir(config);
            }
        }
    }
} catch (e) {
    console.error(e);
    console.log('Unable read config : ' + configPath);
}



