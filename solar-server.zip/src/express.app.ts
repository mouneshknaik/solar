
// import errorHandler from "errorhandler";
import express from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import morgan from "morgan";
import httpContext from "express-http-context";
import moment from "moment-timezone";

const bearerToken = require('express-bearer-token');

const requestIp = require('request-ip');

import { config } from "./config";

export const app = express();


app.use(cors({ origin: true }));
app.use(express.urlencoded({ extended: true }));
app.use(express.json({ limit: '25mb' }));
// app.use(upload.any())
app.use(cookieParser());
app.use(bearerToken());

// app.use(fileUpload());

// Detect IP
app.use(requestIp.mw());

// logger - START
let reqId: number = 0;

const orginalConsole = {
    log: console.log,
    error: console.error,
    dir: console.dir,
};

console.dir = (message?: any) => {
    // Log starts with  day of the month and request number of that day then message
    orginalConsole.log(getDate() + " REQ-" + (httpContext.get('reqId') || "") + " - DIR-VIEW");
    orginalConsole.dir(message);
}
console.log = (message?: any) => {
    // Log starts with  day of the month and request number of that day then message
    orginalConsole.log(getDate() + " REQ-" + (httpContext.get('reqId') || "") + " " + message);
}
console.error = (message?: any) => {
    // Log starts with  day of the month and request number of that day then message
    console.log("---ERROR--- : " + message);
    orginalConsole.error(getDate() + " REQ-" + (httpContext.get('reqId') || "") + " " + message);
}

app.use(httpContext.middleware);
app.use((req: any, res: any, next: any) => {
    req.reqId = ++reqId;
    httpContext.set('reqId', req.reqId);
    console.log(req.method + " >>>> " + req.url);
    next();
});

morgan.token('date', (req: any) => {
    return getDate();
});

morgan.token('reqId', (req: any) => {
    const id = req.reqId;
    return "REQ-" + id;
});

const getDate = () => {
    return moment().tz(config.timezone).format("DD-MM-YYTHH:mm:ss.SSS");
}

app.use(morgan(':date :reqId :method <<<< :url :status :response-time :res[content-length]'));
// Logger - END

app.use(["/health"], require("./routers/health").router);


app.use((req: any, res: any) => {
    res.status(404).send('Not found');
});




export default app;